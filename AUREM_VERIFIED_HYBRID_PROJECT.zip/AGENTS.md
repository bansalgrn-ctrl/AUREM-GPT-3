# AUREM — EXISTING APP; DO NOT REGENERATE

This is a **real existing Android project**, NOT a specification to rebuild.

- **Source of truth:** `app/src/main/assets/index.html`, `app/src/main/assets/*.js`, `app/src/main/assets/*.css`, `app/src/main/java/com/aurem/app/*.kt`, Android XML and `cloudflare/worker.js`.
- **Architecture locked:** native Kotlin + XML WebViewAssetLoader + existing JS modules. Preserve app identity `com.aurem.app` and its boards and pricing.
- The source reference at `SOURCE_REFERENCE/AUREM_RUNTIME_SOURCE_REFERENCE.txt` is FOR READING ONLY. Do not generate a new UI from this document.
- GOOGLE SIGN-IN and AI BOARD STUDIO must continue through their existing native Credential Manager and Cloudflare integration; no mocked/recreated logins.
- Do not invent or embed credentials. Signing certificate and server-side Cloudflare bindings are external.
- Check `00_HYBRID_IMPORT_READ_FIRST.md` and `AUREM_ORIGINAL_VS_AI_STUDIO_COMPARISON.md` for verified parity status.
- No additional features, pricing changes, redesigns, fixes or refactoring are authorized by importing this package.
- The original current-source Kotlin OCR parse defect was repaired with the exact five-line change from the user-supplied AI Studio export; all other original project files are intact.
- If a compile error or missing runtime connection appears, report it without automatically rewriting unrelated files.
