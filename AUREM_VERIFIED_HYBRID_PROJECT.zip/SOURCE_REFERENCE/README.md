Full readable source derived from actual runtime project files. The app loads its real files in app/. This reference is never loaded by the app.
