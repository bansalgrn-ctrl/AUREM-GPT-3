# AUREM VERIFIED HYBRID — READ BEFORE ANY BUILD / IMPORT

**Do not rebuild the UI from source descriptions.** This repository is the full original AUREM Android application, whose original 99 project files are preserved except for the five-line OCR Kotlin syntax repair already made by Google AI Studio in the user's export.

Files are laid out in their real Android paths. `SOURCE_REFERENCE` is non-runtime documentation and must NOT be used as the source for a generated replica.

## Runtime features (present in actual source)

- CORE: `app/src/main/assets/app.js`, `core.js`, `preview.js`, `style.css`
- NON-CORE / CUSTOM BOARD: `noncore.js`, `notebook_boards.js`, `loose_grocery.js`, `smart_replica.js`, `studio.js`, and CSS
- Google Login: `MainActivity.kt`, `AUREMAndroidBridge.kt`, credentials dependencies and `app.js` UI
- Cloudflare AI Board Studio: `studio.js`, `AUREMAndroidBridge.kt`, `cloudflare/worker.js`
- Audit / history / price-memory source: `inventory.js`, `verified.js`, `migration.js`, `app.js`
- Android PDF / printing: `PdfPrintDocumentAdapter.kt`, `AUREMAndroidBridge.kt`, `preview.js`

## Critical dependencies that ZIP cannot carry

- Correct Android signing SHA-1 and OAuth registration; no signing keystore is included
- Cloudflare Worker deployed service, Workers AI bindings and quota KV binding
- Live native device, Google account, Android permissions and data sandbox

Never swap the original installed app with a differently signed test APK or uninstall it to test; doing so could affect access to local data.

Read `AUREM_ORIGINAL_VS_AI_STUDIO_COMPARISON.md` before assuming a feature was deleted in the import.
