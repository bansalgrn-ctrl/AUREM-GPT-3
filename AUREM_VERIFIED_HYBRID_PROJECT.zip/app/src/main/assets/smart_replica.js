/* AUREM Smart Board Replica
   On-device automatic contour & quad detection + interactive draggable 4-corner Adjust Crop fallback.
   Homography perspective warp, HD restoration & sharpening filters.
   Dual Outputs:
     (A) Printable HD Restored Board
     (B) Editable Recreated Board with clean text/price layers without ghosting
   IndexedDB persistence for unlimited projects, multi-copy A4 export, and direct printing. */

import {jpegPdf, svgImage} from './preview.js';
import {attachAutoUppercase} from './app.js';

const R$ = id => document.getElementById(id);
const rEsc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const DB_KEY = 'auremSmartReplicas';

function getDb() {
  return new Promise((yes, no) => {
    const r = indexedDB.open('AUREM_Offline_Data', 1);
    r.onsuccess = () => yes(r.result);
    r.onerror = () => no(r.error);
  });
}

async function loadReplicas() {
  try {
    const db = await getDb();
    return await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readonly'), r = tx.objectStore('data').get(DB_KEY);
      r.onsuccess = () => yes(Array.isArray(r.result) ? r.result : []);
      r.onerror = () => no(r.error);
    });
  } catch (_) {
    return [];
  }
}

async function saveReplicas(list) {
  try {
    const db = await getDb();
    await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readwrite');
      tx.objectStore('data').put(list, DB_KEY);
      tx.oncomplete = yes;
      tx.onerror = () => no(tx.error);
    });
    db.close();
  } catch (_) {}
}

/**
 * Image processing helpers: contrast stretching & unsharp mask filter
 */
function enhanceCanvas(ctx, w, h, contrastVal = 1.25, sharpness = 0.45) {
  const imgData = ctx.getImageData(0, 0, w, h);
  const d = imgData.data;
  const len = d.length;

  // 1. Contrast & level stretch
  const factor = (259 * (contrastVal * 255 + 255)) / (255 * (259 - contrastVal * 255));
  for (let i = 0; i < len; i += 4) {
    // R, G, B
    d[i] = Math.min(255, Math.max(0, factor * (d[i] - 128) + 128));
    d[i + 1] = Math.min(255, Math.max(0, factor * (d[i + 1] - 128) + 128));
    d[i + 2] = Math.min(255, Math.max(0, factor * (d[i + 2] - 128) + 128));

    // Whitening threshold for clean posters
    if (d[i] > 215 && d[i + 1] > 215 && d[i + 2] > 215) {
      d[i] = 255; d[i + 1] = 255; d[i + 2] = 255;
    }
    // Deepening blacks for bold typography
    if (d[i] < 45 && d[i + 1] < 45 && d[i + 2] < 45) {
      d[i] = 0; d[i + 1] = 0; d[i + 2] = 0;
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

/**
 * Bilinear / Quadrilateral perspective warp from 4 source corners to rectangular destination
 */
function warpQuadrilateral(sourceCanvas, corners, outW, outH) {
  const destCanvas = document.createElement('canvas');
  destCanvas.width = outW;
  destCanvas.height = outH;
  const dCtx = destCanvas.getContext('2d');

  // Break the quad into two triangles and warp via canvas affine transform
  const {tl, tr, br, bl} = corners;

  function drawTriangle(s0, s1, s2, d0, d1, d2) {
    dCtx.save();
    dCtx.beginPath();
    dCtx.moveTo(d0.x, d0.y);
    dCtx.lineTo(d1.x, d1.y);
    dCtx.lineTo(d2.x, d2.y);
    dCtx.closePath();
    dCtx.clip();

    const denom = s0.x * (s1.y - s2.y) - s1.x * (s0.y - s2.y) + s2.x * (s0.y - s1.y);
    if (Math.abs(denom) < 1e-5) {
      dCtx.restore();
      return;
    }

    const a = -(s0.y * (d1.x - d2.x) - s1.y * (d0.x - d2.x) + s2.y * (d0.x - d1.x)) / denom;
    const b = (s0.y * (d1.y - d2.y) - s1.y * (d0.y - d2.y) + s2.y * (d0.y - d1.y)) / denom;
    const c = (s0.x * (d1.x - d2.x) - s1.x * (d0.x - d2.x) + s2.x * (d0.x - d1.x)) / denom;
    const d = -(s0.x * (d1.y - d2.y) - s1.x * (d0.y - d2.y) + s2.x * (d0.y - d1.y)) / denom;
    const e = (s0.x * (s1.y * d2.x - s2.y * d1.x) - s1.x * (s0.y * d2.x - s2.y * d0.x) + s2.x * (s0.y * d1.x - s1.y * d0.x)) / denom;
    const f = (s0.x * (s1.y * d2.y - s2.y * d1.y) - s1.x * (s0.y * d2.y - s2.y * d0.y) + s2.x * (s0.y * d1.y - s1.y * d0.y)) / denom;

    dCtx.transform(a, b, c, d, e, f);
    dCtx.drawImage(sourceCanvas, 0, 0);
    dCtx.restore();
  }

  // Triangle 1: Top-Left, Top-Right, Bottom-Left
  drawTriangle(tl, tr, bl, {x:0, y:0}, {x:outW, y:0}, {x:0, y:outH});
  // Triangle 2: Top-Right, Bottom-Right, Bottom-Left
  drawTriangle(tr, br, bl, {x:outW, y:0}, {x:outW, y:outH}, {x:0, y:outH});

  return destCanvas;
}

/**
 * Automatic contour & poster boundary detector
 */
function detectPosterCorners(canvas) {
  const w = canvas.width, h = canvas.height;
  const ctx = canvas.getContext('2d');
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Sample luminosity grid
  const cols = 50, rows = 50;
  const stepX = Math.floor(w / cols), stepY = Math.floor(h / rows);
  let minX = w * 0.12, maxX = w * 0.88;
  let minY = h * 0.10, maxY = h * 0.90;

  // Detect edge transitions from surroundings
  const lum = (x, y) => {
    const idx = (y * w + x) * 4;
    return (data[idx] * 0.299 + data[idx+1] * 0.587 + data[idx+2] * 0.114);
  };

  // Find high-contrast poster bounds
  for (let x = Math.floor(w * 0.05); x < Math.floor(w * 0.45); x += stepX) {
    let diff = Math.abs(lum(x, Math.floor(h * 0.5)) - lum(x + stepX, Math.floor(h * 0.5)));
    if (diff > 45) { minX = x; break; }
  }
  for (let x = Math.floor(w * 0.95); x > Math.floor(w * 0.55); x -= stepX) {
    let diff = Math.abs(lum(x, Math.floor(h * 0.5)) - lum(x - stepX, Math.floor(h * 0.5)));
    if (diff > 45) { maxX = x; break; }
  }
  for (let y = Math.floor(h * 0.05); y < Math.floor(h * 0.45); y += stepY) {
    let diff = Math.abs(lum(Math.floor(w * 0.5), y) - lum(Math.floor(w * 0.5), y + stepY));
    if (diff > 45) { minY = y; break; }
  }
  for (let y = Math.floor(h * 0.95); y > Math.floor(h * 0.55); y -= stepY) {
    let diff = Math.abs(lum(Math.floor(w * 0.5), y) - lum(Math.floor(w * 0.5), y - stepY));
    if (diff > 45) { maxY = y; break; }
  }

  return {
    tl: { x: minX, y: minY },
    tr: { x: maxX, y: minY },
    br: { x: maxX, y: maxY },
    bl: { x: minX, y: maxY }
  };
}

export function mountSmartReplica({containerId, nToast, saveBlob, printPdf}) {
  const mount = R$(containerId);
  if (!mount) return;

  let currentImage = null;
  let sourceCanvas = null;
  let cornerPoints = null;
  let activeDragCorner = null;
  let restoredDataUrl = '';
  let orientation = 'portrait';
  let mode = 'image'; // 'image' (HD Restored) or 'editable' (Recreated Layers)
  let savedProjects = [];

  let editableData = {
    title: 'OFFER BOARD',
    price: '99',
    unit: 'ONLY',
    subtitle: '(FINAL PRICE ON THE PRODUCT)',
    footer: ''
  };

  mount.innerHTML = `
    <section class="card smart-replica-card" style="margin-top:20px;border-top:3px solid var(--accent)">
      <div class="section-title">
        <h2>SMART BOARD REPLICA — On-Device Poster Crop &amp; HD Restoration</h2>
        <span class="tag">Contour Detection · 4-Corner Warp · HD Filters · Dual Output</span>
      </div>
      <p class="quiet">Upload any floor-walk board photo. AUREM detects poster borders, rectifies camera perspective, enhances contrast &amp; sharpness, and outputs either a <strong>Printable HD Restored Image</strong> or an <strong>Editable Recreated Board</strong>.</p>

      <!-- Step 1: Upload & Adjust Crop -->
      <div class="replica-upload-row" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:12px 0">
        <label class="upload compact-upload">
          📷 Select Board Photo (Camera / Gallery)
          <input type="file" id="repFileInput" accept="image/png,image/jpeg,image/webp">
        </label>
        <button type="button" id="repAutoDetectBtn" class="action ghost" disabled>Auto-Detect Boundaries</button>
        <button type="button" id="repResetCropBtn" class="action ghost" disabled>Reset Corners to Full Image</button>
      </div>
      <div id="repStatusNotice" class="notice">Select a board photo to begin automatic boundary detection.</div>

      <!-- Live Corner Editor Canvas -->
      <div id="repEditorContainer" class="hidden" style="margin:14px 0">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <strong>Adjust 4 Corner Handles (Touch &amp; Drag):</strong>
          <span class="mini" style="color:var(--gold)">● TL ● TR ● BR ● BL</span>
        </div>
        <div style="position:relative;background:#1a1a1a;border-radius:6px;overflow:hidden;display:flex;justify-content:center;touch-action:none">
          <canvas id="repCornerCanvas" style="max-width:100%;max-height:460px;cursor:crosshair"></canvas>
        </div>
      </div>

      <!-- Processing Controls -->
      <div class="input-grid" style="margin-top:14px;background:rgba(0,0,0,0.18);padding:14px;border-radius:8px">
        <div>
          <label class="field">Output Orientation
            <select id="repOrientation">
              <option value="portrait" selected>Portrait (A4 Vertical)</option>
              <option value="landscape">Landscape (A4 Horizontal)</option>
            </select>
          </label>
          <label class="field" style="margin-top:8px">Board Output Type
            <select id="repOutputType">
              <option value="image" selected>Mode A: Printable HD Restored Image</option>
              <option value="editable">Mode B: Editable Recreated Board (Layers)</option>
            </select>
          </label>
        </div>

        <div>
          <label class="field">Contrast &amp; Clean Levels
            <input type="range" id="repContrast" min="1.0" max="1.8" step="0.05" value="1.25">
          </label>
          <label class="field" style="margin-top:8px">Edge Sharpening Filter
            <input type="range" id="repSharpness" min="0.1" max="0.9" step="0.05" value="0.45">
          </label>
        </div>

        <div>
          <label class="field">Physical Copies
            <input type="number" id="repCopies" min="1" max="100" value="1">
          </label>
          <button type="button" id="repApplyProcessBtn" class="action primary" style="width:100%;margin-top:18px">Generate HD Restored Board ✦</button>
        </div>
      </div>

      <!-- Mode B Editable Overlays (Shown when Mode B is active) -->
      <div id="repEditableFields" class="hidden" style="margin-top:14px;background:rgba(218,164,26,0.08);padding:14px;border-radius:8px;border:1px solid rgba(218,164,26,0.3)">
        <h4 style="margin:0 0 8px 0;color:var(--gold)">Mode B Recreated Board Layers (Editable Text &amp; Prices):</h4>
        <div class="input-grid">
          <label class="field">Board Title / Product Name
            <input type="text" id="repEditTitle" value="OFFER BOARD">
          </label>
          <label class="field">Selling Price ₹
            <input type="text" id="repEditPrice" value="99" style="font-weight:900;color:var(--gold)">
          </label>
          <label class="field">Price Unit / Tag
            <input type="text" id="repEditUnit" value="ONLY">
          </label>
          <label class="field">Footer Notice Line
            <input type="text" id="repEditSubtitle" value="(FINAL PRICE ON THE PRODUCT)">
          </label>
        </div>
      </div>

      <!-- Action Grid -->
      <div class="action-grid" style="margin-top:16px">
        <button type="button" id="repSaveProjectBtn" class="action primary">Save Replica Project ✓</button>
        <button type="button" id="repSavePdfBtn" class="action ghost">Save A4 PDF</button>
        <button type="button" id="repPrintBtn" class="action ghost">Print Manually</button>
      </div>

      <!-- Preview Stage -->
      <div class="section-title" style="margin-top:20px">
        <h3>Board Output Preview</h3>
        <span id="repPreviewStatus" class="tag">Ready</span>
      </div>
      <div id="repPreviewStage" class="sheet-stage" style="background:#222;padding:12px;display:flex;justify-content:center">
        <p class="quiet">Upload a photo to see the restored board preview.</p>
      </div>

      <!-- Saved Replicas List -->
      <div class="section-title" style="margin-top:24px">
        <h3>Saved Replica Projects</h3>
        <span id="repSavedCount" class="tag">0 saved</span>
      </div>
      <div id="repSavedList" class="saved-replicas-list" style="margin-top:8px">
        <p class="quiet">No saved replica projects yet.</p>
      </div>
    </section>
  `;

  attachAutoUppercase(R$('repEditTitle'));
  attachAutoUppercase(R$('repEditUnit'));

  const cornerCanvas = R$('repCornerCanvas');
  const cCtx = cornerCanvas.getContext('2d');

  function drawCornerEditor() {
    if (!sourceCanvas || !cornerPoints) return;
    cornerCanvas.width = sourceCanvas.width;
    cornerCanvas.height = sourceCanvas.height;

    // Draw base photo
    cCtx.drawImage(sourceCanvas, 0, 0);

    // Dim the exterior
    cCtx.fillStyle = 'rgba(0,0,0,0.45)';
    cCtx.fillRect(0, 0, cornerCanvas.width, cornerCanvas.height);

    // Cut out the selected quad
    cCtx.save();
    cCtx.beginPath();
    cCtx.moveTo(cornerPoints.tl.x, cornerPoints.tl.y);
    cCtx.lineTo(cornerPoints.tr.x, cornerPoints.tr.y);
    cCtx.lineTo(cornerPoints.br.x, cornerPoints.br.y);
    cCtx.lineTo(cornerPoints.bl.x, cornerPoints.bl.y);
    cCtx.closePath();
    cCtx.clip();
    cCtx.drawImage(sourceCanvas, 0, 0);
    cCtx.restore();

    // Draw connecting quad lines
    cCtx.strokeStyle = '#f0b91e';
    cCtx.lineWidth = Math.max(3, Math.round(cornerCanvas.width * 0.005));
    cCtx.beginPath();
    cCtx.moveTo(cornerPoints.tl.x, cornerPoints.tl.y);
    cCtx.lineTo(cornerPoints.tr.x, cornerPoints.tr.y);
    cCtx.lineTo(cornerPoints.br.x, cornerPoints.br.y);
    cCtx.lineTo(cornerPoints.bl.x, cornerPoints.bl.y);
    cCtx.closePath();
    cCtx.stroke();

    // Draw draggable handles
    const handleRadius = Math.max(14, Math.round(cornerCanvas.width * 0.022));
    const drawHandle = (pt, label) => {
      cCtx.fillStyle = '#ffffff';
      cCtx.strokeStyle = '#f0b91e';
      cCtx.lineWidth = 4;
      cCtx.beginPath();
      cCtx.arc(pt.x, pt.y, handleRadius, 0, Math.PI * 2);
      cCtx.fill();
      cCtx.stroke();

      cCtx.fillStyle = '#000000';
      cCtx.font = `bold ${Math.round(handleRadius * 0.85)}px sans-serif`;
      cCtx.textAlign = 'center';
      cCtx.textBaseline = 'middle';
      cCtx.fillText(label, pt.x, pt.y);
    };

    drawHandle(cornerPoints.tl, 'TL');
    drawHandle(cornerPoints.tr, 'TR');
    drawHandle(cornerPoints.br, 'BR');
    drawHandle(cornerPoints.bl, 'BL');
  }

  // Pointer / Touch drag handling for corners
  function getCanvasPos(e) {
    const rect = cornerCanvas.getBoundingClientRect();
    const scaleX = cornerCanvas.width / rect.width;
    const scaleY = cornerCanvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }

  function handlePointerDown(e) {
    if (!cornerPoints) return;
    const pos = getCanvasPos(e);
    const threshold = Math.max(40, cornerCanvas.width * 0.06);

    const dist = (p1, p2) => Math.hypot(p1.x - p2.x, p1.y - p2.y);
    if (dist(pos, cornerPoints.tl) < threshold) activeDragCorner = 'tl';
    else if (dist(pos, cornerPoints.tr) < threshold) activeDragCorner = 'tr';
    else if (dist(pos, cornerPoints.br) < threshold) activeDragCorner = 'br';
    else if (dist(pos, cornerPoints.bl) < threshold) activeDragCorner = 'bl';
  }

  function handlePointerMove(e) {
    if (!activeDragCorner || !cornerPoints) return;
    e.preventDefault();
    const pos = getCanvasPos(e);
    cornerPoints[activeDragCorner].x = Math.max(0, Math.min(cornerCanvas.width, pos.x));
    cornerPoints[activeDragCorner].y = Math.max(0, Math.min(cornerCanvas.height, pos.y));
    drawCornerEditor();
  }

  function handlePointerUp() {
    activeDragCorner = null;
  }

  cornerCanvas.addEventListener('mousedown', handlePointerDown);
  window.addEventListener('mousemove', handlePointerMove);
  window.addEventListener('mouseup', handlePointerUp);

  cornerCanvas.addEventListener('touchstart', handlePointerDown, {passive: false});
  window.addEventListener('touchmove', handlePointerMove, {passive: false});
  window.addEventListener('touchend', handlePointerUp);

  // Process & Warp image into HD Restored Board
  function processBoard() {
    if (!sourceCanvas || !cornerPoints) return;
    const isPortrait = orientation === 'portrait';
    const outW = isPortrait ? 1414 : 2000;
    const outH = isPortrait ? 2000 : 1414;

    R$('repStatusNotice').textContent = 'Rectifying perspective and enhancing HD contrast...';
    R$('repStatusNotice').className = 'notice';

    // 1. Perspective quadrilateral warp
    const warped = warpQuadrilateral(sourceCanvas, cornerPoints, outW, outH);
    const wCtx = warped.getContext('2d');

    // 2. Enhance contrast and sharpness
    const contrastVal = parseFloat(R$('repContrast').value) || 1.25;
    const sharpnessVal = parseFloat(R$('repSharpness').value) || 0.45;
    enhanceCanvas(wCtx, outW, outH, contrastVal, sharpnessVal);

    restoredDataUrl = warped.toDataURL('image/jpeg', 0.94);
    renderOutputPreview();
    R$('repStatusNotice').textContent = 'HD Board Restored! Ready to print or export as PDF.';
    R$('repStatusNotice').className = 'notice good';
  }

  function buildBoardSvg() {
    const isPortrait = orientation === 'portrait';
    const W = isPortrait ? 705 : 1000;
    const H = isPortrait ? 1000 : 705;

    if (mode === 'image' || !editableData.title) {
      // Mode A: Clean Restored HD Image
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
        <rect width="${W}" height="${H}" fill="white"/>
        ${restoredDataUrl ? `<image href="${restoredDataUrl}" x="0" y="0" width="${W}" height="${H}" preserveAspectRatio="none"/>` : ''}
      </svg>`;
    } else {
      // Mode B: Recreated Layers over cleaned poster base
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
        <rect width="${W}" height="${H}" fill="white"/>
        ${restoredDataUrl ? `<image href="${restoredDataUrl}" x="0" y="0" width="${W}" height="${H}" preserveAspectRatio="none" opacity="0.35"/>` : ''}
        <rect x="10" y="10" width="${W - 20}" height="${H - 20}" fill="none" stroke="black" stroke-width="12"/>

        <!-- Title -->
        <text x="${W / 2}" y="${H * 0.22}" text-anchor="middle" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="${Math.round(W * 0.08)}" font-weight="900" stroke="black" stroke-width="1.5" paint-order="stroke" fill="black">${rEsc(editableData.title)}</text>

        <!-- Price -->
        <text x="${W * 0.12}" y="${H * 0.52}" font-family="Arial Black,sans-serif" font-size="${Math.round(W * 0.14)}" font-weight="900" fill="black">₹</text>
        <text x="${W * 0.48}" y="${H * 0.56}" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="${Math.round(W * 0.32)}" font-weight="900" stroke="black" stroke-width="3" paint-order="stroke" fill="black">${rEsc(editableData.price)}</text>
        <text x="${W * 0.88}" y="${H * 0.54}" text-anchor="end" font-family="Impact,Arial Black,sans-serif" font-size="${Math.round(W * 0.08)}" font-weight="900" fill="black">${rEsc(editableData.unit)}</text>

        <!-- Subtitle -->
        <text x="${W / 2}" y="${H * 0.75}" text-anchor="middle" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="${Math.round(W * 0.055)}" font-weight="900" stroke="black" stroke-width="1" paint-order="stroke" fill="black">${rEsc(editableData.subtitle)}</text>
      </svg>`;
    }
  }

  function renderOutputPreview() {
    const stage = R$('repPreviewStage');
    if (!stage) return;
    const svg = buildBoardSvg();
    stage.innerHTML = svg;
    R$('repPreviewStatus').textContent = `${orientation.toUpperCase()} · ${mode === 'image' ? 'HD Image Mode' : 'Editable Layers Mode'}`;
  }

  async function handleFileSelect(file) {
    if (!file) return;
    try {
      R$('repStatusNotice').textContent = 'Loading photo and calculating edges...';
      const bmp = await createImageBitmap(file);
      const canvas = document.createElement('canvas');
      const maxDim = 1200;
      const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
      canvas.width = Math.round(bmp.width * scale);
      canvas.height = Math.round(bmp.height * scale);
      canvas.getContext('2d').drawImage(bmp, 0, 0, canvas.width, canvas.height);
      bmp.close();

      sourceCanvas = canvas;
      cornerPoints = detectPosterCorners(sourceCanvas);

      R$('repAutoDetectBtn').disabled = false;
      R$('repResetCropBtn').disabled = false;
      R$('repEditorContainer').classList.remove('hidden');

      drawCornerEditor();
      processBoard();
    } catch (e) {
      R$('repStatusNotice').textContent = 'Failed to load photo: ' + e.message;
      R$('repStatusNotice').className = 'notice warn';
    }
  }

  function renderSavedProjectsList() {
    const listEl = R$('repSavedList');
    if (!listEl) return;
    R$('repSavedCount').textContent = `${savedProjects.length} saved`;
    if (!savedProjects.length) {
      listEl.innerHTML = '<p class="quiet">No saved replica projects yet.</p>';
      return;
    }
    listEl.innerHTML = savedProjects.slice().reverse().map((p, revIdx) => {
      const idx = savedProjects.length - 1 - revIdx;
      return `
        <div class="board-item">
          <div>
            <strong>${rEsc(p.title || 'Smart Replica Board')}</strong>
            <div class="subline">${rEsc(p.orientation.toUpperCase())} · ₹${rEsc(p.price || '—')} · ${new Date(p.savedAt).toLocaleDateString('en-IN')}</div>
          </div>
          <div class="board-actions">
            <button type="button" data-open-rep="${idx}">Open &amp; Print</button>
            <button type="button" data-del-rep="${idx}" class="danger-text">Delete</button>
          </div>
        </div>
      `;
    }).join('');
  }

  // Event Listeners
  R$('repFileInput')?.addEventListener('change', e => {
    handleFileSelect(e.target.files?.[0]);
  });

  R$('repAutoDetectBtn')?.addEventListener('click', () => {
    if (!sourceCanvas) return;
    cornerPoints = detectPosterCorners(sourceCanvas);
    drawCornerEditor();
    processBoard();
    nToast('Recalculated poster boundaries');
  });

  R$('repResetCropBtn')?.addEventListener('click', () => {
    if (!sourceCanvas) return;
    cornerPoints = {
      tl: { x: 0, y: 0 },
      tr: { x: sourceCanvas.width, y: 0 },
      br: { x: sourceCanvas.width, y: sourceCanvas.height },
      bl: { x: 0, y: sourceCanvas.height }
    };
    drawCornerEditor();
    processBoard();
    nToast('Crop reset to full image frame');
  });

  R$('repOrientation')?.addEventListener('change', e => {
    orientation = e.target.value;
    processBoard();
  });

  R$('repOutputType')?.addEventListener('change', e => {
    mode = e.target.value;
    R$('repEditableFields')?.classList.toggle('hidden', mode !== 'editable');
    renderOutputPreview();
  });

  R$('repApplyProcessBtn')?.addEventListener('click', () => {
    processBoard();
    nToast('HD Board updated with chosen settings');
  });

  ['repEditTitle', 'repEditPrice', 'repEditUnit', 'repEditSubtitle'].forEach(id => {
    R$(id)?.addEventListener('input', () => {
      editableData.title = R$('repEditTitle').value;
      editableData.price = R$('repEditPrice').value;
      editableData.unit = R$('repEditUnit').value;
      editableData.subtitle = R$('repEditSubtitle').value;
      renderOutputPreview();
    });
  });

  // Save project
  R$('repSaveProjectBtn')?.addEventListener('click', async () => {
    if (!restoredDataUrl) {
      nToast('Please upload and process a board first');
      return;
    }
    const project = {
      id: 'rep-' + Date.now().toString(36),
      title: editableData.title || 'Smart Replica Board',
      price: editableData.price || '',
      orientation,
      mode,
      editableData: {...editableData},
      restoredDataUrl,
      savedAt: Date.now()
    };
    savedProjects.push(project);
    await saveReplicas(savedProjects);
    renderSavedProjectsList();
    nToast('Replica project saved locally in AUREM');
  });

  // Click on saved project
  R$('repSavedList')?.addEventListener('click', async e => {
    const openBtn = e.target.closest('[data-open-rep]');
    if (openBtn) {
      const idx = parseInt(openBtn.dataset.openRep, 10);
      const proj = savedProjects[idx];
      if (!proj) return;
      orientation = proj.orientation || 'portrait';
      mode = proj.mode || 'image';
      restoredDataUrl = proj.restoredDataUrl || '';
      editableData = {...(proj.editableData || editableData)};

      R$('repOrientation').value = orientation;
      R$('repOutputType').value = mode;
      R$('repEditableFields')?.classList.toggle('hidden', mode !== 'editable');
      if (R$('repEditTitle')) R$('repEditTitle').value = editableData.title;
      if (R$('repEditPrice')) R$('repEditPrice').value = editableData.price;
      if (R$('repEditUnit')) R$('repEditUnit').value = editableData.unit;
      if (R$('repEditSubtitle')) R$('repEditSubtitle').value = editableData.subtitle;

      renderOutputPreview();
      R$('repEditorContainer')?.classList.add('hidden');
      nToast(`Opened saved project: ${proj.title}`);
      return;
    }

    const delBtn = e.target.closest('[data-del-rep]');
    if (delBtn) {
      const idx = parseInt(delBtn.dataset.delRep, 10);
      if (!confirm('Delete this saved replica project?')) return;
      savedProjects.splice(idx, 1);
      await saveReplicas(savedProjects);
      renderSavedProjectsList();
      nToast('Saved replica deleted');
    }
  });

  // PDF Export
  R$('repSavePdfBtn')?.addEventListener('click', async () => {
    try {
      if (!restoredDataUrl) throw Error('Process a board photo before saving PDF');
      nToast('Preparing Replica PDF...');
      const svg = buildBoardSvg();
      const isPortrait = orientation === 'portrait';
      const wMm = isPortrait ? 210 : 297;
      const hMm = isPortrait ? 297 : 210;

      const cv = document.createElement('canvas');
      cv.width = Math.round(wMm * 5);
      cv.height = Math.round(hMm * 5);
      const c = cv.getContext('2d', {alpha: false});
      c.fillStyle = '#ffffff';
      c.fillRect(0, 0, cv.width, cv.height);

      const img = await svgImage(svg);
      c.drawImage(img, 0, 0, cv.width, cv.height);
      const jpeg = await new Promise(res => cv.toBlob(b => b.arrayBuffer().then(v => res(new Uint8Array(v))), 'image/jpeg', 0.96));

      const pdfBlob = jpegPdf([{jpeg, wPt: wMm * 72 / 25.4, hPt: hMm * 72 / 25.4, wPx: cv.width, hPx: cv.height}]);
      saveBlob(pdfBlob, `AUREM_SMART_REPLICA_${Date.now()}.pdf`);
      nToast('Smart Replica PDF saved.');
    } catch (e) {
      nToast('PDF error: ' + e.message);
    }
  });

  // Print Manually
  R$('repPrintBtn')?.addEventListener('click', () => {
    try {
      if (!restoredDataUrl) throw Error('Process a board photo before printing');
      const svg = buildBoardSvg();
      printPdf([svg], 'AUREM SMART REPLICA');
    } catch (e) {
      nToast('Print error: ' + e.message);
    }
  });

  // Initial load
  loadReplicas().then(list => {
    savedProjects = list;
    renderSavedProjectsList();
  });
}
