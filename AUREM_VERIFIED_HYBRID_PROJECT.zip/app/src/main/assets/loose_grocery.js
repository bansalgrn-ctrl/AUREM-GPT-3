/* AUREM Dynamic Loose Grocery Board Generator
   Authoritative replacement for legacy 51-page Word document catalog.
   Faithful reproduction of authoritative reference image_b7bac9b2.png (WHEAT FLOUR / ₹32.50 / Machine Code 05).
   Integrates all 53 assigned products from LOOSE_MACHINE_CODE_NAMES_COMPLETED master.
   Deterministic offline SVG rendering, stock retail SP resolution, override memory, and multi-copy A4 export. */

import {money, parseMoneyCents} from './core.js';
import {jpegPdf, svgImage} from './preview.js';
import {attachAutoUppercase} from './app.js';

const L$ = id => document.getElementById(id);
const lEsc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export const AUREM_LOOSE_MASTER = [
  { machine: '01', bansal: '2000102', name: 'L.SUGAR BULK-1 kg', gujrati: 'છૂટક ખાંડ', english: 'LOOSE SUGAR' },
  { machine: '02', bansal: '2017959', name: 'L.POHA BULK-1 kg', gujrati: 'પૌવા', english: 'POHA' },
  { machine: '03', bansal: '2017960', name: 'L.NAYLON POHA BULK-1 kg', gujrati: 'નાયલોન પૌવા', english: 'NAYLON POHA' },
  { machine: '04', bansal: '2026251', name: 'L.CHUR POHA BULK-1 kg', gujrati: 'ચુર પૌવા', english: 'CHUR POHA' },
  { machine: '05', bansal: '2019980', name: 'L.ATTA BULK-1 nos', gujrati: 'ઘઉં નો લોટ', english: 'WHEAT FLOUR' },
  { machine: '06', bansal: '2030011', name: 'L.BAJARI ATAA BULK-1 kg', gujrati: 'બાજરી નો લોટ', english: 'BAJARI FLOUR' },
  { machine: '07', bansal: '2019981', name: 'L.BESAN BULK-1 kg', gujrati: 'છૂટક બેસન', english: 'BESAN' },
  { machine: '08', bansal: '2020987', name: 'L.MAIDA BULK-1 kg', gujrati: 'છૂટક મેંદો', english: 'MAIDA' },
  { machine: '09', bansal: '2020988', name: 'L.SOOJI BULK-1 kg', gujrati: 'છૂટક સોજી', english: 'SOOJI' },
  { machine: '10', bansal: '2019214', name: 'L.CHANA DALL BULK-1 kg', gujrati: 'છૂટક ચણા દાળ', english: 'L.CHANA DALL' },
  { machine: '11', bansal: '2019217', name: 'L.MASUR DALL BULK-1 kg', gujrati: 'છૂટક મસૂર દાળ', english: 'L.MASUR DALL' },
  { machine: '12', bansal: '2017954', name: 'L.MOONG DALL BULK-1 kg', gujrati: 'છૂટક મગ દાળ', english: 'L.MOONG DALL' },
  { machine: '13', bansal: '2017958', name: 'L.MOONG FADA BULK-1 kg', gujrati: 'છૂટક મગ ફાડા', english: 'L.MOONG FADA' },
  { machine: '14', bansal: '2019224', name: 'L.TOOR DALL KORI BULK-1 kg', gujrati: 'છૂટક તુવેર દાળ કોરી', english: 'L.TOOR DALL KORI' },
  { machine: '15', bansal: '2019221', name: 'L.TOOR DALL OILY DESHI BULK-1 kg', gujrati: 'છૂટક તુવેર દાળ તેલયુક્ત', english: 'L.TOOR DALL OILY DESHI' },
  { machine: '16', bansal: '2023176', name: 'L.TUVERDALL OILY {IM}BULK-1 kg', gujrati: 'L.JUVAR DHANI', english: 'L.TOOR DALL OILY [IMP]' },
  { machine: '17', bansal: '2019234', name: 'L.URAD DALL BULK-1 kg', gujrati: 'છૂટક અડદ દાળ', english: 'L.URAD DALL' },
  { machine: '18', bansal: '2004745', name: 'L. CHORA WHITE BULK-1 kg', gujrati: 'છુટક ચોરા સફેદ', english: 'L.CHORA WHITE' },
  { machine: '19', bansal: '2023252', name: 'L.MIX KATHOD BULK-1 kg', gujrati: 'છૂટક મિક્ષ કઠોળ', english: 'L.MIX KATHOD' },
  { machine: '20', bansal: '2023177', name: 'L.BASMATI BIRYANI BULK-1 kg', gujrati: 'બાસમતી બિરિયાની ચોખા', english: 'BASMATI BIRYANI RICE' },
  { machine: '21', bansal: '2019016', name: 'L.BASMATI PULAVE RICE BULK-1 kg', gujrati: 'બાસમતી પુલાવ ચોખા', english: 'BASMATI PULAV RICE' },
  { machine: '22', bansal: '2019963', name: 'L.KANKI BULK-1 kg', gujrati: 'છૂટક કણકી', english: 'KANAKI RICE' },
  { machine: '23', bansal: '2019778', name: 'L.RICE BOIL BASMATI BULK-1 kg', gujrati: 'ચોખા બોઇલ બાસમતી', english: 'L.RICE BOIL BASMATI' },
  { machine: '24', bansal: '2019777', name: 'L.RICE BOIL KOLAM BULK-1 kg', gujrati: 'ચોખા બોઇલ કોલમ', english: 'L.RICE BOIL KOLAM' },
  { machine: '25', bansal: '2017965', name: 'L.RICE JIRASAR BULK-1 kg', gujrati: 'ચોખા જીરાસર', english: 'L.RICE JIRASAR' },
  { machine: '26', bansal: '2017966', name: 'L.RICE LACHKARI BULK-1 kg', gujrati: 'ચોખા લચકારી', english: 'L.RICE LACHKARI' },
  { machine: '27', bansal: '2023602', name: 'L.RICE LONG GRAIN BULK-1 kg', gujrati: 'ચોખા લોન્ગ ગ્રેન', english: 'L.RICE LONG GRAIN' },
  { machine: '28', bansal: '2026400', name: 'L.RICE MASOORI BULK-1 kg', gujrati: 'ચોખા મસૂરી', english: 'L.RICE MASOORI' },
  { machine: '29', bansal: '2019226', name: 'L.RICE PARIMAL BULK-1 kg', gujrati: 'ચોખા પરીમલ', english: 'L.RICE PARIMAL' },
  { machine: '30', bansal: '2003169', name: 'L.RICE SHREE RAM WADA KOLAM BULK-1 kg', gujrati: 'ચોખા શ્રી રામ વડા કોલમ', english: 'L.RICE SHREE RAM WADA KOLAM' },
  { machine: '31', bansal: '2019776', name: 'L.RICE STEAM LACHKARI KOLAM BULK-1 kg', gujrati: 'ચોખા સ્ટીમ લચકારી કોલમ', english: 'L.RICE STEAM LACHKARI KOLAM' },
  { machine: '32', bansal: '2003282', name: 'L.JEERA BULK-1 kg', gujrati: 'છૂટક જીરા', english: 'L.JEERA' },
  { machine: '33', bansal: '2019229', name: 'L.WHEAT SHARBATI BULK-1 kg', gujrati: 'ઘઉં શરબતી', english: 'L.WHEAT SHARBATI' },
  { machine: '34', bansal: '2023591', name: 'L.BAJARI BULK-1 kg', gujrati: 'છૂટક બાજરી', english: 'L.BAJARI' },
  { machine: '35', bansal: '2023590', name: 'L.JUVAR BULK-1 kg', gujrati: 'છૂટક જુવાર', english: 'L.JUVAR' },
  { machine: '36', bansal: '2019106', name: 'L.SABUDANA BULK-1 kg', gujrati: 'છૂટક સાબુદાણા', english: 'L.SABUDANA' },
  { machine: '37', bansal: '2019227', name: 'L.GROUDNUT BULK-1 kg', gujrati: 'છૂટક સીંગદાણા', english: 'L.GROUDNUT' },
  { machine: '38', bansal: '2019216', name: 'L.CHANA BROWN BULK-1 kg', gujrati: 'છૂટક ચણા', english: 'L.CHANA' },
  { machine: '39', bansal: '2019215', name: 'L.KABULI CHANA BULK-1 kg', gujrati: 'છૂટક કાબુલી ચણા', english: 'L.CHANA KABULI' },
  { machine: '40', bansal: '2019219', name: 'L.GREEN PEAS BULK-1 kg', gujrati: 'છૂટક લીલા વટાણા', english: 'L.GREEN PEAS' },
  { machine: '41', bansal: '2017952', name: 'L.MOONG BULK-1 kg', gujrati: 'છૂટક મગ', english: 'L.MOONG' },
  { machine: '42', bansal: '2023589', name: 'L.SOYABEAN WADI BULK-1 kg', gujrati: 'સોયાબીન વડી', english: 'L.SOYABEAN WADI' },
  { machine: '43', bansal: '2008253', name: 'L.MIXDAL BULK-1 kg', gujrati: 'છૂટક મિક્ષ દાળ', english: 'L.MIX DALL' },
  { machine: '44', bansal: '2023896', name: 'L.PASTA ALBOW BULK-1 kg', gujrati: 'છૂટક પાસ્તા એલ્બો', english: 'L.PASTA ELBOW' },
  { machine: '45', bansal: '2021839', name: 'L.FRARI POTATO WFR BULK-1 kg', gujrati: 'ફરાળી બટાકા વેફર', english: 'L.FARARI POTATO WAFFER' },
  { machine: '46', bansal: '2021602', name: 'L.FRYMS BULK-1 kg', gujrati: 'છૂટક ફ્રાયમ્સ', english: 'L.FRYMS' },
  { machine: '47', bansal: '2021838', name: 'L.PASTA SPRING BULK-1 kg', gujrati: 'છૂટક પાસ્તા', english: 'L.PASTA' },
  { machine: '48', bansal: '2002870', name: 'L.PIPE FRYUMS BULLK BULK-1 kg', gujrati: 'પાઇપ ફ્રાયમ્સ', english: 'L.PIPE FRYUMS' },
  { machine: '49', bansal: '2024000', name: 'L.RICE PAPDI BULK-1 kg', gujrati: 'ચોખા પાપડી', english: 'L.RICE PAPDI' },
  { machine: '50', bansal: '2022644', name: 'L.MAKHANA BULK-1 kg', gujrati: 'છૂટક મખાના', english: 'L.MAKHANA' },
  { machine: '51', bansal: '2004722', name: 'L.VATANA WHITE BULK-1 kg', gujrati: 'છુટક વટાણા સફેદ', english: 'LOOSE VATANA WHITE' },
  { machine: '52', bansal: '2022835', name: 'JUVAR DHANI BULK-1 kg', gujrati: 'છૂટક જુવાર ધાણી', english: 'L.JUVAR DHANI' },
  { machine: '53', bansal: '2022062', name: 'L.MAKAI DHANI BULK-1 kg', gujrati: 'છૂટક મકાઈ ધાણી', english: 'L.MAKAI DHANI' }
];

const DB_KEY = 'auremLoosePriceMemory';

function getDb() {
  return new Promise((yes, no) => {
    const r = indexedDB.open('AUREM_Offline_Data', 1);
    r.onsuccess = () => yes(r.result);
    r.onerror = () => no(r.error);
  });
}

async function loadLoosePriceMemory() {
  try {
    const db = await getDb();
    return await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readonly'), r = tx.objectStore('data').get(DB_KEY);
      r.onsuccess = () => yes(r.result && typeof r.result === 'object' ? r.result : {});
      r.onerror = () => no(r.error);
    });
  } catch (_) {
    return {};
  }
}

async function saveLoosePriceMemory(mem) {
  try {
    const db = await getDb();
    await new Promise((yes, no) => {
      const tx = db.transaction('data', 'readwrite');
      tx.objectStore('data').put(mem, DB_KEY);
      tx.oncomplete = yes;
      tx.onerror = () => no(tx.error);
    });
    db.close();
  } catch (_) {}
}

/**
 * Format price value cleanly (e.g. 32.50 or 32)
 */
function formatLoosePrice(val) {
  const num = Number(val);
  if (!Number.isFinite(num) || num <= 0) return '0.00';
  if (Number.isInteger(num)) return num.toString();
  return num.toFixed(2);
}

/**
 * Builds the exact SVG board matching reference image_b7bac9b2.png
 */
export function looseGrocerySvg(item, priceOverride = '') {
  const W = 1000, H = 705;
  const machineCode = String(item.machine || '05').padStart(2, '0');
  const gujrati = item.gujrati || 'ઘઉં નો લોટ';
  const english = item.english || 'WHEAT FLOUR';
  const displayPrice = formatLoosePrice(priceOverride || item.price || '32.50');

  // Price length and sizing for huge numerals
  const priceLen = displayPrice.length;
  const priceFontSize = priceLen <= 4 ? 430 : priceLen <= 6 ? 370 : 310;
  const priceY = priceLen <= 4 ? 490 : 475;
  const priceX = priceLen <= 4 ? 420 : 395;
  const priceW = Math.min(540, Math.max(260, priceLen * (priceFontSize * 0.54)));

  // English bottom banner width
  const engLen = english.length;
  const engFontSize = engLen <= 12 ? 96 : engLen <= 18 ? 84 : 70;
  const engTargetW = Math.min(940, Math.max(500, engLen * (engFontSize * 0.6)));

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <rect width="${W}" height="${H}" fill="white"/>

    <!-- Double heavy black border matching image_b7bac9b2.png -->
    <rect x="12" y="12" width="976" height="681" fill="none" stroke="black" stroke-width="12"/>
    <rect x="22" y="22" width="956" height="661" fill="none" stroke="black" stroke-width="4"/>

    <!-- Top-Right Machine Code Box -->
    <g id="machineCodeBox">
      <rect x="745" y="40" width="220" height="240" fill="none" stroke="black" stroke-width="7"/>
      <text x="855" y="96" text-anchor="middle" font-family="Impact,Arial Black,sans-serif" font-size="44" font-weight="900" stroke="black" stroke-width="1.2" paint-order="stroke" fill="black" textLength="202" lengthAdjust="spacingAndGlyphs">MACHINE CODE</text>
      <line x1="745" y1="116" x2="965" y2="116" stroke="black" stroke-width="6"/>
      <text x="855" y="244" text-anchor="middle" font-family="Arial Black,Impact,DejaVu Sans,sans-serif" font-size="142" font-weight="900" stroke="black" stroke-width="3" paint-order="stroke" fill="black">${lEsc(machineCode)}</text>
      <!-- PER KG directly below box -->
      <text x="855" y="325" text-anchor="middle" font-family="Arial Black,Impact,sans-serif" font-size="52" font-weight="900" stroke="black" stroke-width="1.5" paint-order="stroke" fill="black">PER KG</text>
    </g>

    <!-- Dominant massive price with ₹ symbol -->
    <text x="56" y="450" font-family="Arial Black,DejaVu Sans,sans-serif" font-size="160" font-weight="900" fill="black">₹</text>
    <text x="${priceX}" y="${priceY}" text-anchor="middle" font-family="Georgia,DejaVu Serif,Times New Roman,serif" font-size="${priceFontSize}" font-weight="900" stroke="black" stroke-width="4" paint-order="stroke" fill="black" textLength="${priceW.toFixed(0)}" lengthAdjust="spacingAndGlyphs">${lEsc(displayPrice)}</text>

    <!-- 'Only' on the right of the price -->
    <text x="870" y="490" text-anchor="middle" font-family="Georgia,DejaVu Serif,serif" font-size="108" font-weight="900" stroke="black" stroke-width="2.5" paint-order="stroke" fill="black">Only</text>

    <!-- Large Gujarati name line -->
    <text x="500" y="605" text-anchor="middle" font-family="Shruti,Nirmala UI,Gujarati,sans-serif,Arial Black" font-size="110" font-weight="900" stroke="black" stroke-width="1.8" paint-order="stroke" fill="black">${lEsc(gujrati)}</text>

    <!-- Heavy English name along the bottom -->
    <text x="500" y="675" text-anchor="middle" font-family="Arial Black,Impact,DejaVu Sans,sans-serif" font-size="${engFontSize}" font-weight="900" stroke="black" stroke-width="3.5" paint-order="stroke" fill="black" textLength="${engTargetW}" lengthAdjust="spacingAndGlyphs">${lEsc(english)}</text>
  </svg>`;
}

/**
 * Multi-copy 1/1 A4 landscape page plan
 */
export function loosePagePlan(item, priceOverride = '', copies = 1) {
  const total = Math.max(1, Math.min(300, parseInt(copies, 10) || 1));
  const board = looseGrocerySvg(item, priceOverride);
  const wMm = 297, hMm = 210; // A4 landscape

  const svgs = [];
  for (let i = 0; i < total; i++) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${wMm}mm" height="${hMm}mm" viewBox="0 0 ${wMm} ${hMm}"><rect width="${wMm}" height="${hMm}" fill="white"/>`;
    s += board.replace(/^<svg[^>]*>/, `<svg x="0" y="0" width="${wMm}" height="${hMm}" viewBox="0 0 1000 705" preserveAspectRatio="none">`);
    s += '</svg>';
    svgs.push(s);
  }

  return { svgs, pagesCount: total, totalCopies: total, size: '1/1' };
}

/**
 * Mounts the Loose Grocery Board Generator into the container
 */
export function mountLooseGrocery({containerId, getContext, nToast, saveBlob, printPdf}) {
  const mount = L$(containerId);
  if (!mount) return;

  let currentItem = AUREM_LOOSE_MASTER.find(x => x.machine === '05') || AUREM_LOOSE_MASTER[0];
  let customPrice = '';
  let copiesCount = 1;
  let priceMemory = {};
  let previewIndex = 0;
  let activePlan = null;

  mount.innerHTML = `
    <section class="card loose-grocery-card" style="margin-top:20px;border-top:3px solid var(--gold)">
      <div class="section-title">
        <h2>DYNAMIC LOOSE GROCERY BOARD GENERATOR</h2>
        <span class="tag">Authoritative Master · 53 Assigned Products · 1/1 A4</span>
      </div>
      <p class="quiet">Search by Machine Code (e.g. <strong>05</strong>) or Bansal CODE (e.g. <strong>2019980</strong>). Automatic stock price lookup with manual override memory. 100% offline deterministic generator matching official retail standard.</p>

      <!-- Search & Selection Bar -->
      <div class="loose-search-row" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0">
        <label class="field" style="flex:1;min-width:260px;margin:0">Search Machine Code (01-53), Bansal CODE, or Product Name
          <input type="text" id="looseSearchInput" placeholder="Enter Machine Code e.g. 05 or Bansal CODE" autocomplete="off">
        </label>
        <button type="button" id="looseSearchBtn" class="action primary" style="align-self:flex-end">Find Product</button>
      </div>

      <!-- Quick Category / Machine Code Selector -->
      <label class="field" style="margin-top:10px">Or Select from 53 Assigned Loose Products:
        <select id="looseSelectProduct" style="font-size:15px;font-weight:600">
          ${AUREM_LOOSE_MASTER.map(p => `
            <option value="${p.machine}" ${p.machine === currentItem.machine ? 'selected' : ''}>
              [${p.machine}] ${lEsc(p.english)} (${lEsc(p.gujrati)}) — Bansal ${p.bansal}
            </option>
          `).join('')}
        </select>
      </label>

      <!-- Current Product Details & Price Control -->
      <div class="input-grid" style="margin-top:14px;background:rgba(0,0,0,0.18);padding:14px;border-radius:8px">
        <div>
          <label class="field">Machine Code (Boxed)
            <input type="text" id="looseMachineCode" value="${currentItem.machine}" readonly style="font-weight:900;font-size:18px">
          </label>
          <label class="field" style="margin-top:8px">Bansal CODE
            <input type="text" id="looseBansalCode" value="${currentItem.bansal}" readonly>
          </label>
        </div>

        <div>
          <label class="field">Gujarati Name Line
            <input type="text" id="looseGujratiInput" value="${lEsc(currentItem.gujrati)}">
          </label>
          <label class="field" style="margin-top:8px">English Bottom Name
            <input type="text" id="looseEnglishInput" value="${lEsc(currentItem.english)}">
          </label>
        </div>

        <div>
          <label class="field">Retail Selling Price ₹ (PER KG)
            <div style="display:flex;gap:6px">
              <input type="text" id="loosePriceInput" inputmode="decimal" placeholder="32.50" style="font-weight:900;font-size:18px;color:var(--gold)">
              <button type="button" id="looseResetPriceBtn" class="action ghost" style="padding:4px 10px;font-size:12px" title="Reset to REG-STAT price">Stock Price</button>
            </div>
          </label>
          <div id="looseStockStatus" class="mini" style="margin-top:4px;color:var(--muted)">Checking REG-STAT stock price...</div>
          <label class="field" style="margin-top:8px">Physical Copies (1/1 A4 Sheets)
            <input type="number" id="looseCopiesInput" min="1" max="300" step="1" value="1">
          </label>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="action-grid" style="margin-top:16px">
        <button type="button" id="looseSaveMemoryBtn" class="action primary">Save Custom Price Override ✓</button>
        <button type="button" id="loosePdfBtn" class="action ghost">Save 1/1 A4 PDF</button>
        <button type="button" id="loosePrintBtn" class="action ghost">Print 1/1 Manually</button>
      </div>

      <!-- Preview Stage -->
      <div class="section-title" style="margin-top:20px">
        <h3>1/1 A4 Sheet Preview</h3>
        <span id="loosePreviewStatus" class="tag">Sheet 1 of 1 · Machine Code 05</span>
      </div>
      <div id="loosePreviewStage" class="sheet-stage" style="background:#222;padding:12px;display:flex;justify-content:center"></div>
      <div class="pager" style="margin-top:10px">
        <button type="button" id="loosePrevSheet" class="action ghost">← Previous Sheet</button>
        <span id="looseSheetTag" class="tag">1 / 1</span>
        <button type="button" id="looseNextSheet" class="action ghost">Next Sheet →</button>
      </div>
    </section>
  `;

  attachAutoUppercase(L$('looseEnglishInput'));

  function getStockPrice(bansalCode) {
    const ctx = getContext();
    const p = ctx.master?.products?.[bansalCode];
    if (p && p.retail) return p.retail;
    return '';
  }

  function resolveItemPrice() {
    // 1. Saved price memory for this machine code / bansal code
    const saved = priceMemory[currentItem.bansal] || priceMemory[currentItem.machine];
    if (saved) return { price: saved, source: 'Custom Saved Override' };

    // 2. Active REG-STAT stock retail price
    const stock = getStockPrice(currentItem.bansal);
    if (stock) return { price: stock, source: 'REG-STAT Retail SP' };

    // 3. Fallback default
    return { price: currentItem.machine === '05' ? '32.50' : '50.00', source: 'Standard Default' };
  }

  function selectProduct(item) {
    currentItem = item;
    L$('looseSelectProduct').value = item.machine;
    L$('looseMachineCode').value = item.machine;
    L$('looseBansalCode').value = item.bansal;
    L$('looseGujratiInput').value = item.gujrati;
    L$('looseEnglishInput').value = item.english;

    const prInfo = resolveItemPrice();
    customPrice = prInfo.price;
    L$('loosePriceInput').value = customPrice;
    L$('looseStockStatus').textContent = `Price Source: ${prInfo.source} (₹${customPrice})`;
    renderPreview();
  }

  function renderPreview() {
    currentItem.gujrati = L$('looseGujratiInput').value.trim() || currentItem.gujrati;
    currentItem.english = L$('looseEnglishInput').value.trim().toUpperCase() || currentItem.english;
    customPrice = L$('loosePriceInput').value.trim() || customPrice;
    copiesCount = parseInt(L$('looseCopiesInput').value, 10) || 1;

    activePlan = loosePagePlan(currentItem, customPrice, copiesCount);
    const totalPages = activePlan.pagesCount;
    previewIndex = Math.max(0, Math.min(previewIndex, totalPages - 1));

    L$('loosePreviewStatus').textContent = `Sheet ${previewIndex + 1} of ${totalPages} · Machine Code ${currentItem.machine} (${currentItem.english})`;
    L$('looseSheetTag').textContent = `${previewIndex + 1} / ${totalPages}`;
    L$('loosePrevSheet').disabled = previewIndex === 0;
    L$('looseNextSheet').disabled = previewIndex >= totalPages - 1;

    const stage = L$('loosePreviewStage');
    if (stage && activePlan.svgs[previewIndex]) {
      stage.innerHTML = activePlan.svgs[previewIndex];
    }
  }

  function findProductByQuery(raw) {
    const q = String(raw || '').trim();
    if (!q) return;

    // 1. Match machine code (with or without leading zero)
    const normMachine = q.padStart(2, '0');
    let matched = AUREM_LOOSE_MASTER.find(x => x.machine === normMachine || x.machine === q);

    // 2. Match Bansal code
    if (!matched) {
      matched = AUREM_LOOSE_MASTER.find(x => x.bansal === q || x.bansal.endsWith(q));
    }

    // 3. Match name in English or Gujarati
    if (!matched) {
      const lower = q.toLowerCase();
      matched = AUREM_LOOSE_MASTER.find(x => x.english.toLowerCase().includes(lower) || x.gujrati.includes(q) || x.name.toLowerCase().includes(lower));
    }

    if (matched) {
      selectProduct(matched);
      nToast(`Matched Machine Code ${matched.machine}: ${matched.english}`);
    } else {
      nToast(`No loose product matched "${q}". Select from dropdown.`);
    }
  }

  // Event Listeners
  L$('looseSelectProduct')?.addEventListener('change', e => {
    const item = AUREM_LOOSE_MASTER.find(x => x.machine === e.target.value);
    if (item) selectProduct(item);
  });

  L$('looseSearchBtn')?.addEventListener('click', () => {
    findProductByQuery(L$('looseSearchInput').value);
  });

  L$('looseSearchInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') findProductByQuery(L$('looseSearchInput').value);
  });

  ['looseGujratiInput', 'looseEnglishInput', 'loosePriceInput', 'looseCopiesInput'].forEach(id => {
    L$(id)?.addEventListener('input', renderPreview);
    L$(id)?.addEventListener('change', renderPreview);
  });

  L$('looseResetPriceBtn')?.addEventListener('click', () => {
    const stock = getStockPrice(currentItem.bansal);
    if (stock) {
      customPrice = stock;
      L$('loosePriceInput').value = stock;
      L$('looseStockStatus').textContent = `Reset to REG-STAT stock price: ₹${stock}`;
      renderPreview();
      nToast(`Reset to REG-STAT stock price ₹${stock}`);
    } else {
      nToast(`Bansal CODE ${currentItem.bansal} not in current REG-STAT import.`);
    }
  });

  L$('looseSaveMemoryBtn')?.addEventListener('click', async () => {
    const p = L$('loosePriceInput').value.trim();
    if (!p || parseMoneyCents(p) === null) {
      nToast('Please enter a valid price');
      return;
    }
    priceMemory[currentItem.bansal] = p;
    priceMemory[currentItem.machine] = p;
    await saveLoosePriceMemory(priceMemory);
    L$('looseStockStatus').textContent = `Custom override saved: ₹${p}`;
    nToast(`Saved custom price ₹${p} for Machine Code ${currentItem.machine}`);
  });

  L$('loosePrevSheet')?.addEventListener('click', () => {
    previewIndex--;
    renderPreview();
  });

  L$('looseNextSheet')?.addEventListener('click', () => {
    previewIndex++;
    renderPreview();
  });

  // Save PDF
  L$('loosePdfBtn')?.addEventListener('click', async () => {
    try {
      nToast('Preparing 1/1 Loose Grocery PDF...');
      const plan = loosePagePlan(currentItem, customPrice, copiesCount);
      const sheets = [];

      for (let i = 0; i < plan.svgs.length; i++) {
        const svg = plan.svgs[i];
        const wMm = 297, hMm = 210; // A4 landscape
        const cv = document.createElement('canvas');
        cv.width = Math.round(wMm * 5);
        cv.height = Math.round(hMm * 5);
        const c = cv.getContext('2d', {alpha: false});
        c.fillStyle = '#ffffff';
        c.fillRect(0, 0, cv.width, cv.height);

        const img = await svgImage(svg);
        c.drawImage(img, 0, 0, cv.width, cv.height);
        const jpeg = await new Promise(res => cv.toBlob(b => b.arrayBuffer().then(v => res(new Uint8Array(v))), 'image/jpeg', 0.96));
        sheets.push({jpeg, wPt: wMm * 72 / 25.4, hPt: hMm * 72 / 25.4, wPx: cv.width, hPx: cv.height});
      }

      const pdfBlob = jpegPdf(sheets);
      const filename = `AUREM_LOOSE_${currentItem.machine}_${currentItem.english.replace(/\s+/g, '_')}_${Date.now()}.pdf`;
      saveBlob(pdfBlob, filename);
      nToast('Loose grocery board PDF saved.');
    } catch (err) {
      nToast('PDF generation failed: ' + err.message);
    }
  });

  // Print Manually
  L$('loosePrintBtn')?.addEventListener('click', () => {
    try {
      const plan = loosePagePlan(currentItem, customPrice, copiesCount);
      printPdf(plan.svgs, `AUREM LOOSE GROCERY - ${currentItem.english}`);
    } catch (err) {
      nToast('Print error: ' + err.message);
    }
  });

  // Initial load
  loadLoosePriceMemory().then(mem => {
    priceMemory = mem;
    selectProduct(currentItem);
  });
}
